package com.example.kitlabs_d_0031.firechat.Adapter;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.kitlabs_d_0031.firechat.R;
import com.google.firebase.database.DatabaseReference;

public class HomeScreenAdapter extends RecyclerView.Adapter<HomeScreenAdapter.MyViewHolder> {

    private Context context;
    DatabaseReference myRef;

    public HomeScreenAdapter(Context contexts, DatabaseReference myRef) {

        this.context = contexts;
        this.myRef = myRef;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.chat_layout, parent, false);
        return new MyViewHolder(itemView);

    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder myViewHolder, int i) {

    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    @Override
    public int getItemCount() {

        return 5;

    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        TextView name, mess_prev;
        ImageView image;
        LinearLayout ll_chatcard;

        public MyViewHolder(View view) {
            super(view);


        }
    }
}

