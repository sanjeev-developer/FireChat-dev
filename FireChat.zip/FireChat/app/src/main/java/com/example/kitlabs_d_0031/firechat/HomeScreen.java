package com.example.kitlabs_d_0031.firechat;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.example.kitlabs_d_0031.firechat.Adapter.HomeScreenAdapter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import butterknife.BindView;
import butterknife.ButterKnife;

public class HomeScreen extends AppCompatActivity {

    HomeScreenAdapter homeScreenAdapter;
    LinearLayoutManager layoutManager;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference myRef;


    @BindView(R.id.my_recycler_view)
    RecyclerView rec_homescreen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_screen);

        ButterKnife.bind(this);

        rec_homescreen=findViewById(R.id.my_recycler_view);
        firebaseDatabase = FirebaseDatabase.getInstance();

        myRef = firebaseDatabase.getReference("Users");

        homeScreenAdapter = new HomeScreenAdapter(HomeScreen.this,myRef);
        layoutManager = new LinearLayoutManager(HomeScreen.this);
        layoutManager.setStackFromEnd(true);
        rec_homescreen.setLayoutManager(layoutManager);
        rec_homescreen.setItemAnimator(new DefaultItemAnimator());
        rec_homescreen.setAdapter(homeScreenAdapter);
    }
}